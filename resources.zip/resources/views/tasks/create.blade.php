@extends('layouts.app')

@section('title', 'Create Task')

@section('content')
    <h1>Create New Task</h1>
    <!-- Adăugați aici formularul pentru crearea unui nou task -->
@endsection