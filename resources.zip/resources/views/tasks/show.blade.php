@extends('layouts.app')

@section('title', 'Detalii sarcină')

@section('content')
    <h1>Detalii sarcină</h1>

    <x-task-card :task="$task" />

    <a href="{{ route('tasks.index') }}">Înapoi la lista de sarcini</a>
@endsection