@props(['task'])

<div class="task-card">
    <h2>{{ $task['title'] ?? 'Fără titlu' }}</h2>
    <div class="task-info">
        @if(isset($task['description']))
            <p>{{ $task['description'] }}</p>
        @endif
        <p><strong>Creat la:</strong> {{ $task['created_at'] ?? 'Necunoscut' }}</p>
        <p><strong>Actualizat la:</strong> {{ $task['updated_at'] ?? 'Necunoscut' }}</p>
        <p><strong>Stare:</strong> {{ isset($task['completed']) ? ($task['completed'] ? 'Finalizată' : 'Nefinalizată') : 'Necunoscut' }}</p>
        <p><strong>Prioritate:</strong> <x-task-priority :priority="$task['priority'] ?? 'Necunoscută'" /></p>
        <p><strong>Responsabil:</strong> {{ $task['assigned_to'] ?? 'Nealocat' }}</p>
    </div>
    <div class="task-actions">
        <a href="{{ route('tasks.edit', $task['id']) }}" class="btn btn-edit">Editează</a>
        <form action="{{ route('tasks.destroy', $task['id']) }}" method="POST">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-delete">Șterge</button>
        </form>
    </div>
</div>