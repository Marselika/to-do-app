<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = [
            [
                'id' => 1,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 1',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Ridicată',
                'assigned_to' => 'John Doe'
            ],
            [
                'id' => 2,
                'title' => 'Proiect Nou',
                'description' => 'Descrierea proiectului 2',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Scăzută',
                'assigned_to' => 'John Doe'
            ],
            [
                'id' => 3,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 3',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Medie',
                'assigned_to' => 'Jane Smith'
            ],
        ];
    
        return View::make('tasks.index', ['tasks' => $tasks]);
    }

    public function search(Request $request) {

    }

    public function show($id)
    {
        $task = [
            'id' => $id,
            'title' => 'Titlul sarcinii ' . $id,
            'description' => 'Descrierea detaliată a sarcinii ' . $id, // Asigurați-vă că această linie există
            'created_at' => now()->subDays(rand(1, 30))->format('Y-m-d H:i:s'),
            'updated_at' => now()->subDays(rand(0, 5))->format('Y-m-d H:i:s'),
            'completed' => rand(0, 1) == 1,
            'priority' => ['Scăzută', 'Medie', 'Ridicată'][rand(0, 2)],
            'assigned_to' => ['John Doe', 'Jane Smith', 'Mike Johnson'][rand(0, 2)],
        ];
    
        return View::make('tasks.show', ['task' => $task]);
    }
    public function create()
    {
        // Va fi implementat mai târziu
        return View::make('tasks.create');
    }

    public function store(Request $request)
    {
        // Va fi implementat mai târziu
    }

    public function edit($id)
    {
        // Va fi implementat mai târziu
        return View::make('tasks.edit', ['id' => $id]);
    }

    public function update(Request $request, $id)
    {
        // Va fi implementat mai târziu
    }

    public function destroy($id)
    {
        // Va fi implementat mai târziu
    }
}